# Weather App

## Overview

A web application that fetches weather data for a specified city.

## Features

- Real-time weather data.
- Temperature and weather description.

## Technologies Used

- HTML
- JavaScript

## How to Run

1. Replace `YOUR_API_KEY` with your OpenWeather API key.

2. Open weather_app.html in a web browser.

3. Enter the city name and click "Get Weather".